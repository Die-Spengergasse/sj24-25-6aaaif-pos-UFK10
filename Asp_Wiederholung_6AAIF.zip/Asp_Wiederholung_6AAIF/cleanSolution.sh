find . -type d -name .vs -exec rm -rf {} \;
find . -type d -name bin -exec rm -rf {} \;
find . -type d -name obj -exec rm -rf {} \;
find . -type d -name packages -exec rm -rf {} \;
